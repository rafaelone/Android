package com.example.logonrm.estudo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Estudo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estudo);
    }

    public void bandeira (View v){
        Intent it = new Intent(this, Bandeira.class);
        startActivity(it);
    }

    public void botoes (View v){
        Intent it = new Intent(this, Botoes.class);
        startActivity(it);

    }

}

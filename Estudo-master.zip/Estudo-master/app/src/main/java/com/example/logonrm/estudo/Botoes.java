package com.example.logonrm.estudo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class Botoes extends AppCompatActivity {

    TextView txt;
    int valor = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_botoes);

        txt = (TextView) findViewById(R.id.zero);
    }

    public void incrementar (View v){

        if (valor <  10){
            valor ++;
            txt.setText("" + valor);

        }else{
            Toast.makeText(this, R.string.limite10, Toast.LENGTH_SHORT).show();
        }

    }


    public void decrementar (View v ){
        if (valor > 0){
            valor --;
            txt.setText(""+ valor);
        }else{
            Toast.makeText(this, R.string.limite0, Toast.LENGTH_SHORT).show();
        }
    }
}

package exemplologin.fiap.com.br.exemplodelogin;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    EditText edtUsuario;
    EditText edtPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        edtUsuario = (EditText) findViewById(R.id.edtUsuario);
        edtPassword = (EditText) findViewById(R.id.edtPassword);
    }


    public void logar (View v){
        String usuario = edtUsuario.getText().toString();
        String senha = edtPassword.getText().toString();

        if (usuario.equals("fiap") && senha.equals("fiap123")){
            Intent it = new Intent(this, MainActivity.class);
            startActivity(it);
            Toast.makeText(this, getString(R.string.mensagem_sucesso), Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, getString(R.string.mensagem_erro), Toast.LENGTH_SHORT).show();
        }


    }

    public void cadastrar(View v){
        Intent it = new Intent(this, CadastrarActivity.class);
        startActivity(it);
    }

}

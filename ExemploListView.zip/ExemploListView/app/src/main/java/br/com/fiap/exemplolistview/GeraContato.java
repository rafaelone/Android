package br.com.fiap.exemplolistview;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by logonrm on 23/03/2017.
 */

public class GeraContato {

    public static List<Contato> listaContatos(){
        List<Contato> contatos = new ArrayList<>();

        contatos.add(new Contato("Joao", "(11)1111-1111", "Hello there, i'm using FIAP zap", R.drawable.p2));
        contatos.add(new Contato("Maria", "(11)2222-2222", "Ola", R.drawable.p3));

        return contatos;
    }
}

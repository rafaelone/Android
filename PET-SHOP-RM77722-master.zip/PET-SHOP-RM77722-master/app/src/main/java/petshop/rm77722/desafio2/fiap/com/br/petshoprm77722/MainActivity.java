package petshop.rm77722.desafio2.fiap.com.br.petshoprm77722;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    TextView resultado;
    RadioGroup grupoCachoro;
    CheckBox femea;
    CheckBox adestrado;
    CheckBox vacina;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       resultado = (TextView) findViewById(R.id.valor);

        grupoCachoro = (RadioGroup) findViewById(R.id.grupoDog);


        femea = (CheckBox) findViewById(R.id.femea);
        adestrado = (CheckBox) findViewById(R.id.adestrado);
        vacina = (CheckBox) findViewById(R.id.todasVacinas);


        final CheckBox checkBox = (CheckBox) findViewById(R.id.todasVacinas);


    }


    public void Calcular (View v) {
        int selected = grupoCachoro.getCheckedRadioButtonId();
        double valor = 0;
        if (selected == R.id.bc){
            valor = 800;
            resultado.setText(getString(R.string.rs)+valor);
        }else if (selected == R.id.pb){
            valor = 750;
            resultado.setText(getString(R.string.rs)+valor);
        }else if (selected == R.id.pa){
            valor = 700;
            resultado.setText(getString(R.string.rs)+valor);
        }else if (selected == R.id.pc){
            valor = 800;
            resultado.setText(getString(R.string.rs)+valor);
        }

        if (femea.isChecked()){
            valor = valor + 180;
            resultado.setText(getString(R.string.rs)+valor);
        }
        if (adestrado.isChecked()){
            valor = valor + 400;
            resultado.setText(getString(R.string.rs)+valor);
        }
        if (vacina.isChecked()){
            valor = valor + 200;
            resultado.setText(getString(R.string.rs)+valor);
        }




    }

}

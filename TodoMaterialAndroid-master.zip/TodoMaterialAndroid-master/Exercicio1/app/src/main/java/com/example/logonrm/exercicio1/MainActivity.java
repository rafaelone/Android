package com.example.logonrm.exercicio1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView numeros;
    int numero = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        numeros = (TextView) findViewById(R.id.numeros);


    }

    public void incrementar (View v){

    if (numero < 10){
        numero++;
        numeros.setText("" +numero);
    }else{
        Toast.makeText(this, "Contador so pode incrementar ate 10", Toast.LENGTH_SHORT).show();
    }

    }

    public void decrementar (View v){


            if (numero < 10 && numero > 0){
                numero--;
                numeros.setText("" +numero);
            }else{
                Toast.makeText(this, "Contador so pode decrementar ate 0", Toast.LENGTH_SHORT).show();
            }

        }
    }



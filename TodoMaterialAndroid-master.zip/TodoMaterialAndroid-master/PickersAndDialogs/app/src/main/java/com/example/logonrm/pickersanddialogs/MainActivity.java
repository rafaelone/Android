package com.example.logonrm.pickersanddialogs;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.icu.util.Calendar;

import android.icu.util.GregorianCalendar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    /*DatePicker dtpAniversario;
    AutoCompleteTextView actvPaises;
    TimePicker tmpHorario;
    String[]paises = new String []{"Argentina","Brasil","Chile","Dinamarca","Escocia"};*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       /* actvPaises = (AutoCompleteTextView) findViewById(R.id.actvPaises);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, paises);
        actvPaises.setAdapter(adapter);

        dtpAniversario = (DatePicker) findViewById(R.id.dpAniversario);
        tmpHorario = (TimePicker) findViewById(R.id.tmpHorario);*/
    }

    public void salvar (View v){

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int i, int i1, int i2) {
                Toast.makeText(MainActivity.this,i +  "/" + i1 + "/" + i2, Toast.LENGTH_SHORT).show();
            }
        }, 2017, 03, 02);
        datePickerDialog.show();


        /*ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Carregando");
        progressDialog.setMessage("Aguarde");
        progressDialog.show();
        */


/*

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.titulo);
        builder.setMessage(R.string.mensagem_qualquer);
        builder.setCancelable(false);
        builder.setIcon(android.R.drawable.ic_dialog_alert);
        builder.setPositiveButton(R.string.aceitar, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainActivity.this, R.string.clicou_ok, Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton(R.string.fechar, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainActivity.this, R.string.clicou_fechar, Toast.LENGTH_SHORT).show();
            }
        });
        builder.show();
*/
        /*
        //TimerPicker
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            int hour = tmpHorario.getHour();
            int minute = tmpHorario.getMinute();
        }
*/


        /*
        --date picker

        int year = dtpAniversario.getYear();
        int month = dtpAniversario.getMonth()+1;
        int day = dtpAniversario.getDayOfMonth();

       // Calendar calendar = new GregorianCalendar(year,month,day);
        //calendar.getTimeInMillis();

        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle(getString(R.string.data_escolhida));
        dialog.setMessage(day + "/" + month + "/" + year);
        dialog.show();*/
    }

}


/*
*
*
*   <AutoCompleteTextView
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:id="@+id/actvPaises"
        />
* <TimePicker
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:id="@+id/tmpHorario"
        />

    <DatePicker
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:calendarViewShown="false"
        android:id="@+id/dpAniversario"
        />

        */
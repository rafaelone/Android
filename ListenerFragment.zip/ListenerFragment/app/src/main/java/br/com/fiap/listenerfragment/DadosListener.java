package br.com.fiap.listenerfragment;

import android.support.v4.app.Fragment;

/**
 * Created by logonrm on 05/04/2017.
 */
public interface DadosListener {

    void receberDados(Object object);



}

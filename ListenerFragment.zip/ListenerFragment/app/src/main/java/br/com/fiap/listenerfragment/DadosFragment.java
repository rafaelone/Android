package br.com.fiap.listenerfragment;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class DadosFragment extends Fragment {

    DadosListener mListener;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mListener.receberDados(this);

        return inflater.inflate(R.layout.fragment_dados, container, false);
        }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (!((((Activity) context) instanceof DadosListener))){
            Log.d("DEBUG", "A classe exibe o fragmente nao implementa DadosListener");
            return;
        }
                mListener = (DadosListener) context;
    }
}

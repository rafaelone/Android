package br.com.fiap.recyclerview;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by logonrm on 29/03/2017.
 */

public class GeraContato {

    public static List<Contato> listaContatos(){
        List<Contato> contatos  = new ArrayList<>();
        contatos.add(new Contato("Joao", "11 1111-1111", "ola", R.drawable.foto));
        contatos.add(new Contato("paulo","11 11111111", "ola", R.drawable.foto));
        return contatos;
    }
}

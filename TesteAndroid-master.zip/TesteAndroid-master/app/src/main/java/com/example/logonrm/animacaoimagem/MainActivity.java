package com.example.logonrm.animacaoimagem;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private Animation animation;
    private ImageView imgAleatorio;
    private int [] imagens = {
            R.drawable.img1,
            R.drawable.img2,
            R.drawable.img3,
            R.drawable.img4,
            R.drawable.img5,
            R.drawable.img6,
            R.drawable.img7,
            R.drawable.img8
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imgAleatorio = (ImageView) findViewById(R.id.imgAleatorio);
    animation = AnimationUtils.loadAnimation(this, R.anim.rotacao);
    }

    public void jogar(View v){
        Random r = new Random();
        imgAleatorio.startAnimation(animation);
    for (int i=0; i<animation.getRepeatCount(); i++){
        int rolar = r.nextInt(8);
        imgAleatorio.setImageResource(imagens[rolar]);
    }

    }
}

package br.com.fiap.fragmentsexemplos;

import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;

public class MainActivity extends AppCompatActivity {

    FrameLayout fragmenContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fragmenContainer = (FrameLayout) findViewById(R.id.fragmentContainer);
    }


    public void alteraFragment(Fragment fragment){
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragmentContainer, fragment)
                .addToBackStack(null)
                .commit();
    }

    public void exibir_carro1(View view) {
       alteraFragment(new Carro1Fragment());
    }


    public void exibir_carro2(View view) {
       alteraFragment(new Carro2Fragment());
    }
}
